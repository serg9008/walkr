/* Evan Boggs (etboggs)
 * Mark De Zwaan (mdezwaan)
 * C343/A594
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Set;
import java.util.Collection;
import java.util.Iterator;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

import org.json.JSONObject;
import org.json.JSONArray;


public class Graph {
    private static final double max_length = 255.0;
    private HashMap<String,Node> campusGraph;


    // **************************** constructor ****************************

    public Graph(String filename) {
        campusGraph = new HashMap<String,Node>();
        initNodes(filename);
        try {
            LinkedList<Photo> photos = Flickr.findPhotosByTag("c343fall2010");
            addNodes(photos);
            addEdges(photos);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    /* Parse JSON array of nodes to initialise graph.
     */
    // based on http://answers.oreilly.com/topic/257-how-to-parse-json-in-java/
    private void initNodes(String filename) {
        try {
            FileReader nodelist = new FileReader(new File(filename));
            BufferedReader reader = new BufferedReader(nodelist);
            StringBuilder sb = new StringBuilder();
            String line;
            while (reader.ready())
                sb.append(reader.readLine());
            String jsonText = sb.toString();

            JSONObject obj = new JSONObject(jsonText);
            JSONArray nodes = obj.getJSONArray("nodes");
            for (int i = 0; i < nodes.length(); i++) {
                JSONObject node = nodes.getJSONObject(i);
                String name = node.getString("name").toLowerCase();
                double lat = node.getDouble("lat");
                double lon = node.getDouble("lon");
                Node nodeToAdd = new Node(name, lat, lon);
                campusGraph.put(name, nodeToAdd);
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    /* Add photos gathered from flickr to nodes of graph
     */
    private void addNodes(LinkedList<Photo> photos) {
        Iterator<Photo> it = photos.iterator();
        while (it.hasNext()) {
            Photo photo = it.next();
            ArrayList<String> tags = photo.getTags();
            String nodeBC = null;

            // for each photo, determine if tags have keywords "node"
            for (int i = 0; i < tags.size(); i++)
                if (tags.get(i).startsWith("node"))
                    nodeBC = tags.get(i).substring(4);

            // if photo was taken at a node, add it to the appropriate
            // node's list of photos
            if (nodeBC != null) {
                if (this.contains(nodeBC))
                    this.get(nodeBC).addPhoto(photo);
                else {
                    String name = nodeBC;
                    double lat = photo.getLatitude();
                    double lon = photo.getLongitude();
                    Node nodeToAdd = new Node(name, lat, lon);
                    nodeToAdd.addPhoto(photo);
                    campusGraph.put(name, nodeToAdd);
                }
            }
        }

        return;
    }

    /* Add photos gathered from flickr to edges of graph
     */
    private void addEdges(LinkedList<Photo> photos) {
        Iterator<Photo> it = photos.iterator();
        while (it.hasNext()) {
            Photo photo = it.next();
            ArrayList<String> tags = photo.getTags();
            LinkedList<String> fromBC = new LinkedList<String>();
            LinkedList<String> towardBC = new LinkedList<String>();

            // for each photo, determine if tags have keywords "from", or 
            // "toward"
             for (int i = 0; i < tags.size(); i++) {
                if (tags.get(i).startsWith("from"))
                    fromBC.add(tags.get(i).substring(4));
                if (tags.get(i).startsWith("toward"))
                    towardBC.add(tags.get(i).substring(6));
            }

            // if photo was taken at an edge, iterate through the from/toward 
            // tag combinations...
            for (int i = 0; i < fromBC.size(); i++) {
                String startBC = fromBC.get(i);
                if (!(this.contains(startBC)))
                    continue;
                Node start = this.get(startBC);

                for (int j = 0; j < towardBC.size(); j++) {
                    String endBC = towardBC.get(j);
                    if (!(this.contains(endBC)))
                        continue;
                    Node end = this.get(endBC);

                    // if corresponding start/end edge exists, add photo to it
                    if (start.containsEdge(end)) {
                        Edge edge = start.getEdge(end);
                        edge.addPhoto(photo);
                    }
                    // if not, make a new edge, add the photo, and then add the
                    // edge to the start node
                    else {
                        Edge edgeToAdd = new Edge(start, end);
                        edgeToAdd.addPhoto(photo);
                        start.addEdge(edgeToAdd);
                    }
                }
            }
        }
        return;
    }


    // ************************** shortestPath() **************************

    /* Uses Dijkstra's algorithm to calculate the shortest path from a given 
     * start and end node; if either one is unreachable (i.e., an isolated 
     * node), then it finds the shortest path from/to the nearest reachable 
     * node; if nodes are part of two (or more) unconnected graphs, it will 
     * stich together multiple partial paths from the start to end
     */
    public LinkedList<String> shortestPath(String start, String end) {
       LinkedList<String> shortestPath = new LinkedList<String>();
        HashMap<String,Node> untriedTermini = new HashMap<String,Node>();
        untriedTermini.putAll(campusGraph);

        // Check to see if start node does not have edges; if not, select 
        // nearest node n from untriedTermini, remove it from untriedTermini, 
        // and then call shortestPath again with start == n
        String newStart = start;
        while (!(this.get(newStart).hasEdges()) && !(newStart.equals(end))) {
            shortestPath.add(newStart);
            newStart = getNewStart(newStart, end, shortestPath);
        }

        // remove the start and end from untriedTermini, then run shortestPath
        // on start and end
        untriedTermini.remove(newStart);
        untriedTermini.remove(end);
        LinkedList<String> newPath = shortestPathHelper(newStart, end, 
                                                        untriedTermini);
        if (!(shortestPath.contains(newPath.getLast())))
            shortestPath.addAll((Collection) newPath);

        // Check to see if our tentative shortest path ends at the specified 
        // end node.  If not, try getting a path from the node closest to the 
        // tentative end to the real end, and then stich the two paths together
        newStart = shortestPath.getLast();
        while (!(newStart.equals(end))) {
            newStart = getNewStart(newStart, end, shortestPath);
            untriedTermini.remove(newStart);
            newPath = shortestPathHelper(newStart, end, untriedTermini);
            if (!(shortestPath.contains(newPath.getLast())))
                shortestPath.addAll((Collection) newPath);
            else
                shortestPath.add(newStart);
            newStart = shortestPath.getLast();
        }

        return shortestPath;
    }

    /* Helper for shortestPath which gets a new start node which must be 
     * closer to the end than the old start
     */
    private String getNewStart(String start, String end, LinkedList<String> alreadyVisited) {
        HashMap<String,Node> untriedStarts = new HashMap<String,Node>();
        untriedStarts.putAll(campusGraph);
        untriedStarts.remove(start);

        // remove all the nodes in the path so far from untriedStarts
        for (int i = 0; i < alreadyVisited.size(); i++)
            untriedStarts.remove(alreadyVisited.get(i));

        // while the distance from the start to the end is less than the 
        // distance between the newStart to the end, keep getting a newStart
        String newStart = getClosestNode(start, untriedStarts);
        while ((getDistanceBetweenNodes(start, end) < 
                getDistanceBetweenNodes(newStart, end)) && 
               (!(newStart.equals(end)))) {
            untriedStarts.remove(newStart);
            newStart = getClosestNode(start, untriedStarts);
        }

        return newStart;
    }

    /* Helper for shortestPath which does the heavy lifting.  Checks to see if 
     * the start and end nodes are the same, then runs Dijkstra's Algorithm on 
     * the graph to find the shortest path, then checks to see if the end node 
     * was reached (re-running with the next-nearest node if it wasn't).
     */
    private LinkedList<String> shortestPathHelper(String start, String end, HashMap<String,Node> untriedTermini) {
        // check to see if start == end
        if (start.equals(end)) {
            LinkedList<String> shortestPath = new LinkedList<String>();
            shortestPath.add(start);
            return shortestPath;
        }

        // Set all of the nodes' prevNode to null
        Set keys = this.keySet();
        Iterator<String> it = keys.iterator();
        while (it.hasNext()) {
            Node node = this.get(it.next());
            node.prevNode = null;
        }

        // Initialise HashMap of unvisited nodes
        HashMap<String,Node> unvisited = new HashMap<String,Node>();
        HashMap<String,Double> distance = new HashMap<String,Double>();
        unvisited.putAll(campusGraph);
        unvisited.remove(start);
        distance.put(start, 0.0);

        // Initialise HashMap of distance from start node to current node --
        // for start node to neighbors, set to actual values, for all other 
        // nodes, set to 255 == INF
        Set unvisitedKeys = unvisited.keySet();
        it = unvisitedKeys.iterator();
        while (it.hasNext()) {
            String vertex = it.next();
            double length = length(start, vertex);
            distance.put(vertex, length);
            if (length < max_length) {
                this.get(vertex).prevNode = start;
            }
        }

        // Visit all nodes in the graph, updating the distance "array" and the 
        // prevNode for each one
        while (unvisited.size() != 0) {
            String w = getKeyWithMinDistance(distance, unvisited);
            unvisited.remove(w);
            unvisitedKeys = unvisited.keySet();
            it = unvisitedKeys.iterator();
            while (it.hasNext()) {
                String v = it.next();
                if ((distance.get(w) + length(w, v)) < distance.get(v)) {
                    distance.put(v, (distance.get(w) + length(w, v)));
                    this.get(v).prevNode = w;
                }
            }
        }

        // Check to see if end node does not have a previous node; if not, 
        // select nearest node n from untriedTermini, remove it from 
        // untriedTermini, and then call shortestPath again with end == n
        Node endNode = this.get(end);
        if (endNode.prevNode == null) {
            LinkedList<String> visitedKeys = new LinkedList<String>();
            visitedKeys.add(end);
            String newEnd = getNewStart(end, start, visitedKeys);
            untriedTermini.remove(newEnd);
            return shortestPathHelper(start, newEnd, untriedTermini);
        }

        // Construct a LinkedList of shortestPath by visiting the prevNode of 
        // every node from end to start
        LinkedList<String> shortestPath = new LinkedList<String>();
        String prevNode = end;
        while (!(prevNode.equals(start))) {
            shortestPath.addFirst(prevNode);
            prevNode = this.get(prevNode).prevNode;
        }
        shortestPath.addFirst(start);

        return shortestPath;
    }

    /* Helper for shortestPath; returns the key (from the set of keys in the 
     * HashMap untriedTermini) which is closest to the given node
     */
    private String getClosestNode(String node, HashMap<String,Node> untriedTermini) {
        // get set of untried keys from untriedTermini and set closestNode to 
        // the first one
        Set untriedKeys = untriedTermini.keySet();
        Iterator<String> it = untriedKeys.iterator();
        String closestNode = it.next();
        double closestDistance = getDistanceBetweenNodes(node, closestNode);

        // iterate through the keys and, if one is closer to the target node, 
        // update closestNode to it
        while (it.hasNext()) {
            String nextNode = it.next();
            double nextDistance = getDistanceBetweenNodes(node, nextNode);
            if (nextDistance < closestDistance) {
                closestNode = nextNode;
                closestDistance = nextDistance;
            }
        }

        return closestNode;
    }

    /* Helper for getClosestNode; returns distance between nodes.
     */
    private double getDistanceBetweenNodes(String start, String end) {
        double startLat = this.getLatitude(start);
        double startLon = this.getLongitude(start);
        double endLat = this.getLatitude(end);
        double endLon = this.getLongitude(end);
        double distance = Math.sqrt(Math.pow((startLat - endLat), 2.0) + 
                                    Math.pow((startLon - endLon), 2.0));
        return distance;
    }

    /* Helper for shortestPath; returns the length of the edge between the 
     * given start and end nodes.
     */
    private double length(String start, String end) {
        double length = max_length;
        Node startNode = this.get(start);
        Node endNode = this.get(end);
        if (startNode.containsEdge(endNode))
            length = startNode.getEdge(endNode).length;
        return length;
    }

    /* Helper for shortestPath; returns the key (from the set of unvisited 
     * keys stored in HashMap unvisited) which has the minimum distance from 
     * the start node to the key (according to the HashMap distance).
     */
    private String getKeyWithMinDistance(HashMap<String,Double> distance, HashMap<String,Node> unvisited) {
        // get set of unvisited keys from unvisited and set minKey to the 
        // first one
        Set unvisitedKeys = unvisited.keySet();
        Iterator<String> it = unvisitedKeys.iterator();
        String minKey = it.next();

        // iterate through the keys and, if one has a smaller distance, update 
        // minKey to it
        while (it.hasNext()) {
            String vertex = it.next();
            if (distance.get(vertex) < distance.get(minKey))
                minKey = vertex;
        }

        return minKey;
    }


    // ************************** getPathPhotos() **************************

    /* Takes a LinkedList of nodes along a path and returns a LinkedList of 
     * Photos, sorted by distance, along that path.
     */
    public LinkedList<Photo> getPathPhotos(LinkedList<String> path) {
        LinkedList<Photo> pathPhotos = new LinkedList<Photo>();
        LinkedList<Photo> edgePhotos = new LinkedList<Photo>();
        for (int i = 0; i < (path.size() - 1); i++) {
            // set start and end nodes to first and second nodes in path
            String start = path.get(i);
            String end = path.get(i + 1);
            Node startNode = this.get(start);
            Node endNode = this.get(end);

            // get the photos along the start-end edge, sort them, add the 
            // photo at the end node which is closest to the start node, and 
            // add all of the results to pathPhotos
            if (startNode.containsEdge(endNode)) {
                edgePhotos = startNode.getEdge(endNode).photos;
                edgePhotos = sortPhotosByDistance(edgePhotos, start);
            }
            Photo nodePhoto = getEndPhotoClosestToStart(start, end);
            if (nodePhoto != null)
                edgePhotos.add(nodePhoto);
            pathPhotos.addAll((Collection<Photo>) edgePhotos);
            edgePhotos.clear();
        }

        return pathPhotos;
    }

    /* Helper for getPathPhotos; takes a start and end node and returns the 
     * photo of the end node which is closest to the start node
     */
    private Photo getEndPhotoClosestToStart(String start, String end) {
        Node startNode = this.get(start);
        Node endNode = this.get(end);

        // get startNode.photos iterator and set closestPhoto to the first one
        if (!(endNode.hasPhotos()))
            return null;
        Iterator<Photo> it = endNode.photos.iterator();
        Photo closestPhoto = it.next();
        double closestDistance = getDistanceBetweenPhotoAndNode(closestPhoto, 
                                                                start);
        
        // iterate through the photos and, if one has a smaller distance, 
        // update closestPhoto to it
        while (it.hasNext()) {
            Photo nextPhoto = it.next();
            double nextDistance = getDistanceBetweenPhotoAndNode(nextPhoto, 
                                                                 start);
            if (nextDistance < closestDistance) {
                closestPhoto = nextPhoto;
                closestDistance = nextDistance;
            }
        }

        return closestPhoto;
    }

    /* Helper for getClosestPhoto and sortPhotosByDistance; returns distance 
     * between photo and node.
     */
    private double getDistanceBetweenPhotoAndNode(Photo photo, String node) {
        double photoLat = photo.getLatitude();
        double photoLon = photo.getLongitude();
        double nodeLat = this.getLatitude(node);
        double nodeLon = this.getLongitude(node);
        double distance = Math.sqrt(Math.pow((photoLat - nodeLat), 2.0) + 
                                    Math.pow((photoLon - nodeLon), 2.0));
        return distance;
    }

    /* Helper for getPathPhotos; takes a LinkedList of photos and a Node and 
     * sorts the list by distance from the node; code taken then modified from:
     * www.roseindia.net/java/beginners/arrayexamples/InsertionSort.shtml
     */
    private LinkedList<Photo> sortPhotosByDistance(LinkedList<Photo> pathPhotos, String start) {
        for (int i = 1; i < pathPhotos.size(); i++){
            int j = i;
            Photo key = pathPhotos.get(i);
            double keyDistance = getDistanceBetweenPhotoAndNode(key, start);
            double nextDistance = getDistanceBetweenPhotoAndNode(pathPhotos.get(j-1), start);
            while ((j > 0) && (nextDistance > keyDistance)) {
                pathPhotos.set(j, pathPhotos.get(j-1));
                nextDistance = getDistanceBetweenPhotoAndNode(pathPhotos.get(j-1), start);
                j--;
            }
            pathPhotos.set(j, key);
        }
        return pathPhotos;
    }


    // ********************** contains() and getters **********************

    /* Returns the set of keys (nodes) contained in the graph
     */
    public Set keySet() {
        return campusGraph.keySet();
    }

    /* Returns true if graph contains a node with an ID matching the given key
     */
    public boolean contains(String key) {
        if (campusGraph.containsKey(key))
            return true;
        return false;
    }

    /* Returns the latitude of the node matching the given key
     */
    public double getLatitude(String key) {
        return campusGraph.get(key).latitude;
    }

    /* Returns the longitude of the node matching the given key
     */
    public double getLongitude(String key) {
        return campusGraph.get(key).longitude;
    }

    /* Returns a list of nodes to which the given node has edges
     */
    public LinkedList<String> getEdges(String key) {
        LinkedList<String> edges = new LinkedList<String>();
        Node keyNode = this.get(key);
        if (keyNode.hasEdges())
            edges = keyNode.getDestNodes();
        return edges;
    }

    /* Returns a String representation of the graph
     */
    public String toString() {
        Set set = this.keySet();
        Iterator<String> it = set.iterator();
        StringBuilder sb = new StringBuilder();
        while (it.hasNext())
            sb.append(this.get(it.next()).toString());
        return sb.toString();
    }

    /* Returns a Node matching the given key
     */
    private Node get(String key) {
        return campusGraph.get(key);
    }


    // ************************ private Node class ************************

    private class Node {
        private String ID;
        private LinkedList<Photo> photos;
        private double latitude;
        private double longitude;
        private LinkedList<Edge> edges;
        private String prevNode;

        public Node(String ID, double latitude, double longitude) {
            this.ID = ID;
            this.latitude = latitude;
            this.longitude = longitude;
            this.photos = new LinkedList<Photo>();
            this.edges = new LinkedList<Edge>();
            this.prevNode = null;
        }

        public void addPhoto(Photo photo) {
            photos.add(photo);
        }

        public void addEdge(Edge edge) {
            edges.add(edge);
        }

        public boolean hasPhotos() {
            if (photos.size() == 0)
                return false;
            else
                return true;
        }

        public boolean hasEdges() {
            if (edges.size() == 0)
                return false;
            else
                return true;
        }

        public boolean containsEdge(Node end) {
            for (int i = 0; i < edges.size(); i++) {
                Edge currentEdge = edges.get(i);
                if (end.equals(currentEdge.end))
                    return true;
            }
            return false;
        }

        public Edge getEdge(Node end) {
            Edge edge = null;
            for (int i = 0; i < edges.size(); i++) {
                Edge currentEdge = edges.get(i);
                if (end.equals(currentEdge.end))
                    edge = currentEdge;
            }
            return edge;
        }

        public LinkedList<String> getDestNodes() {
            LinkedList<String> destinations = new LinkedList<String>();
            for (int i = 0; i < edges.size(); i++) {
                String destination = edges.get(i).end.ID;
                destinations.add(destination);
            }
            return destinations;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder("========================\n");
            sb.append("ID: " + this.ID + "\n");
            sb.append("lat: " + this.latitude + "\n");
            sb.append("lon: " + this.longitude + "\n");
            sb.append("Photos:\n");
            for (int i = 0; i < photos.size(); i++) {
                sb.append("\ttags: " + photos.get(i).getTags() + "\n");
            }                
            sb.append("Edges:\n");
            for (int i = 0; i < edges.size(); i++) {
                sb.append("\tstart: " + edges.get(i).start.ID);
                sb.append(" end: " + edges.get(i).end.ID);
                sb.append(" length: " + edges.get(i).length);
                sb.append(" PHOTOS = " + edges.get(i).photos.size() + "\n");
            }
            sb.append("\n");
            return sb.toString();
        }
    }


    // ************************ private Edge class ************************

    private class Edge {
        private Node start;
        private Node end;
        private double length;
        private LinkedList<Photo> photos;

        public Edge(Node start, Node end) {
            this.start = start;
            this.end = end;
            this.length = calculateDistance(start, end);
            this.photos = new LinkedList<Photo>();
        }

        private double calculateDistance(Node start, Node end) {
            double startLat = start.latitude;
            double startLon = start.longitude;
            double endLat = end.latitude;
            double endLon = end.longitude;
            double distance = Math.sqrt(Math.pow((startLat - endLat), 2.0) +
                                        Math.pow((startLon - endLon), 2.0));
            return distance;
        }

        public void addPhoto(Photo photo) {
            photos.add(photo);
        }
    }

}
