/* Mark De Zwaan (mdezwaan)
 * Evan Boggs (etboggs)
 * C343/A594
 */

import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.xml.xpath.XPathConstants;
import org.w3c.dom.*;
import java.lang.Math;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.LinkedList;


public class Flickr {

    private static final String latitude = "39.170998";
    private static final String longitude = "-86.516799";
    private static String api_key = "e7027a5e1ea23330d7d79603cf366e35";


    /* Returns a LinkedList of Photos retrieved from Flickr using the provided 
     * tag and location
     */
    public static LinkedList<Photo> findPhotosByTag(String tag) throws IOException {

        ArrayList<String> ids = new ArrayList<String>();
        ArrayList<String> titles = new ArrayList<String>();
        ArrayList<Double> latitudes = new ArrayList<Double>();
        ArrayList<Double> longitudes = new ArrayList<Double>();
        ArrayList<String> tags = new ArrayList<String>();
        int curPage = 1;
        int numPages = 1;
        int totalPhotos = 0;

        for(curPage = 1; curPage <= numPages; curPage++) {

            // Get results from flickr
            String xmlResult = flickrSearch(tag, Integer.toString(curPage));
            XPathReader xReader = new XPathReader(xmlResult);

            // Update numPages and totalPhotos
            String pages = (String)xReader.read("//photos/@pages",
                                                XPathConstants.STRING);
            numPages = Integer.parseInt(pages);
            String total = (String)xReader.read("//photos/@total",
                                                XPathConstants.STRING);
            totalPhotos = Integer.parseInt(total);

            // Set up NodeLists to read IDs, titles, and coordinates
            NodeList idList = (NodeList)xReader.read("//photo/@id", 
                                                     XPathConstants.NODESET);
            NodeList titleList = (NodeList)xReader.read("//photo/@title", 
                                                        XPathConstants.NODESET);
            NodeList latList = (NodeList)xReader.read("//photo/@latitude", 
                                                      XPathConstants.NODESET);
            NodeList lonList = (NodeList)xReader.read("//photo/@longitude", 
                                                      XPathConstants.NODESET);
            NodeList tagList = (NodeList)xReader.read("//photo/@tags", 
                                                      XPathConstants.NODESET);

            // Put results from flickr into attribute lists
            for(int i = 0; i < idList.getLength(); i++) {
                ids.add(idList.item(i).getNodeValue());
                titles.add(titleList.item(i).getNodeValue());
                latitudes.add(Double.parseDouble(latList.item(i).getNodeValue()));
                longitudes.add(Double.parseDouble(lonList.item(i).getNodeValue()));
                tags.add(tagList.item(i).getNodeValue());
            }

            System.out.println("Still retrieving results from Flickr, " +
                               "page " + curPage + " of " + numPages);
        }

        System.out.println("Finished getting results from Flickr!");

        LinkedList<Photo> flickrResults = new LinkedList<Photo>();
        flickrResults = resultsToLL(ids, titles, latitudes, longitudes, tags, 
                                    totalPhotos);
        return flickrResults;
    }

    /* Helper for findPhotosByTag; retrieves XML result from Flickr search 
     * using given tag
     */
    private static String flickrSearch(String tag, String page) throws IOException {
        String url = "http://api.flickr.com/services/rest/?method=flickr.photos.search";
        url += "&api_key=" + api_key;
        url += "&tags=" + tag;
        url += "&extras=geo,tags";
        url += "&hasgeo=true";
        url += "&page=" + page;
        return httpGet(url);
    }

    /* Helper for findPhotosByTag; code for making a restful Get request
     * by Jaimie Murdock
     */
    private static String httpGet(String urlStr) throws IOException {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        if (conn.getResponseCode() != 200) {
            throw new IOException(conn.getResponseMessage());
        }

        // Buffer the result into a string
        BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = rd.readLine()) != null) {
            sb.append(line);
        }
        rd.close();

        conn.disconnect();
        return sb.toString();
    }

    /* Helper for findPhotosByTag; puts information from attribute lists into 
     * a LinkedList of Photos
     */
    private static LinkedList<Photo> resultsToLL(ArrayList<String> ids, ArrayList<String> titles, ArrayList<Double> latitudes, ArrayList<Double> longitudes, ArrayList<String> tags, int totalPhotos) {
        LinkedList<Photo> flickrResults = new LinkedList<Photo>();
        for (int i = 0; i < totalPhotos; i++) {
            Photo flickrPhoto = new Photo(ids.get(i), titles.get(i), 
                                          tags.get(i));
            flickrPhoto.setLatitude(latitudes.get(i));
            flickrPhoto.setLongitude(longitudes.get(i));
            flickrResults.add(flickrPhoto);
        }

        System.out.println("Finished putting results into DLL!");

        return flickrResults;
    }


    /* Takes a photo, gets its jpeg (size 500x500) from flickr, and returns 
     * that as an Image
     */
    public static Image getImage(Photo photo) throws IOException {
        String xmlResult = flickrGetInfo(photo.getImageID());
        XPathReader xReader = new XPathReader(xmlResult);
        String farmID = (String)xReader.read("//photo/@farm", XPathConstants.STRING);
        String serverID = (String)xReader.read("//photo/@server", XPathConstants.STRING);
        String secret = (String)xReader.read("//photo/@secret", XPathConstants.STRING);
        StringBuilder result = new StringBuilder("http://farm");
        result.append(farmID).append(".static.flickr.com/").append(serverID);
        result.append("/").append(photo.getImageID()).append("_");
        result.append(secret).append(".jpg");
        URL photoURL = new URL(result.toString());
        return ImageIO.read(photoURL);
    }

    /* Helper for getImage and getThumbnail.  Retrieves XML data from Flickr 
     * photo with given id
     */
    private static String flickrGetInfo(String id) throws IOException {
        String url = "http://api.flickr.com/services/rest/?method=flickr.photos.getInfo";
        url += "&api_key=" + api_key;
        url += "&photo_id=" + id;
        return httpGet(url);
    }


    /* Takes a photo, gets its jpeg (size 100x100) from flickr, and returns 
     * that as an Image
     */
    public static Image getThumbnail(Photo photo) throws IOException {
        String xmlResult = flickrGetInfo(photo.getImageID());
        XPathReader xReader = new XPathReader(xmlResult);
        String farmID = (String)xReader.read("//photo/@farm", XPathConstants.STRING);
        String serverID = (String)xReader.read("//photo/@server", XPathConstants.STRING);
        String secret = (String)xReader.read("//photo/@secret", XPathConstants.STRING);
        StringBuilder result = new StringBuilder("http://farm");
        result.append(farmID).append(".static.flickr.com/").append(serverID);
        result.append("/").append(photo.getImageID()).append("_");
        result.append(secret).append("_t.jpg");
        URL photoURL = new URL(result.toString());
        return ImageIO.read(photoURL);
    }

}
