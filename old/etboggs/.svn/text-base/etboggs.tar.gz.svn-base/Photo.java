/* Mark De Zwaan (mdezwaan)
 * Evan Boggs (etboggs)
 * C343/A594
 */

import java.util.Comparator;
import java.util.ArrayList;
import java.util.Arrays;
import java.awt.Image;
import java.io.IOException;


public class Photo {
    private String imageID;
    private String title;
    private double latitude;
    private double longitude;
    private ArrayList<String> tags;
    private Image image;
    private Image thumbnail;

    public Photo(String imageID, String title, String tags) {
        this.imageID = imageID;
        this.title = title;
        this.tags = new ArrayList<String>(Arrays.asList(tags.split(" ")));
        this.image = null;
        this.thumbnail = null;
    }

    // Sets latitude of this photo
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    // Set longitude of this photo
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    // Returns imageID of this photo
    public String getImageID() {
        return imageID;
    }

    // Returns title of this photo
    public String getTitle() {
        return title;
    }

    // Returns latitude of this photo
    public double getLatitude() {
        return latitude;
    }

    // Returns longitude of this photo
    public double getLongitude() {
        return longitude;
    }

    // Returns ArrayList of tags of this photo
    public ArrayList<String> getTags() {
        return tags;
    }

    // Returns true if photo is tagged with specified tag
    public boolean hasTag(String tag) {
        return tags.contains(tag);
    }

    // Returns the image of this photo (500x500)
    public Image getImage() {
        if (this.image == null) {
            try {
                this.image = Flickr.getImage(this);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return this.image;
    }

    // Returns the thumbnail of this photo (100x100)
    public Image getThumbnail() {
        if (this.thumbnail == null) {
            try {
                this.thumbnail = Flickr.getThumbnail(this);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return this.thumbnail;
    }

    /* Returns a string representation of this Photo object
     */
    public String toString() {
        StringBuilder endString = new StringBuilder("<ID: ");
        endString.append(imageID);
        endString.append(" Title: ");
        endString.append(title);
        endString.append(">");
        return endString.toString();
    }

    /* Checks for equality among Photo objects according to imageID value
     */
    public boolean equals(Photo comparePhoto) {
        boolean result = false;
        if (this.imageID.equals(comparePhoto.getImageID()))
            result = true;
        return result;
    }


    public static class TitleComparator implements Comparator {
        public int compare(Object photo1, Object photo2) {
            Photo pht1 = (Photo)photo1;
            Photo pht2 = (Photo)photo2;
            return pht1.getTitle().compareTo(pht2.getTitle());
        }

        public boolean equals(Object comparator) {
            return this.equals((Comparator)comparator);
        }
    }

    public static class IDComparator implements Comparator {
        public int compare(Object photo1, Object photo2) {
            Photo pht1 = (Photo)photo1;
            Photo pht2 = (Photo)photo2;
            return pht1.getImageID().compareTo(pht2.getImageID());
        }

        public boolean equals(Object comparator) {
            return this.equals((Comparator)comparator);
        }
    }

}
