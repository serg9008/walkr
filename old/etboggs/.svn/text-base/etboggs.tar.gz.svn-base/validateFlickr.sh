javac *.java
echo "==== Program Output ===="
java TestFlickr > output.txt
echo ""

echo "==== Parsing output ===="
echo "node photos: `grep -c tags output.txt`"
echo "edge photos: `grep PHOTOS output.txt | awk '{ s=s+$NF }; END{ print s }'`"
echo ""

echo "==== Parsing XML ===="
wget -q "http://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=e7027a5e1ea23330d7d79603cf366e35&tags=c343_fall2010&hasgeo=true&extras=geo,tags" -O flickr.xml
wget -q "http://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=e7027a5e1ea23330d7d79603cf366e35&tags=c343_fall2010&hasgeo=true&extras=geo,tags&page=2" -O - >>flickr.xml
wget -q "http://api.flickr.com/services/rest/?method=flickr.photos.search&api_key=e7027a5e1ea23330d7d79603cf366e35&tags=c343_fall2010&hasgeo=true&extras=geo,tags&page=3" -O - >>flickr.xml

echo -n "XML total: "
echo "`grep -c 'photo id' flickr.xml`"

echo -n "XML node: "
echo "`grep -c node flickr.xml`"

echo -n "XML 1 from / 1 toward: "
echo "`grep -o 'tags=.*from.*' flickr.xml | grep 'tags=.*toward.*' - | grep -v 'tags=.*from.*from.*' | grep -vc 'tags=.*toward.*toward.*'`"

echo -n "XML 1 from / 2 toward: "
echo "`grep -o 'tags=.*from.*' flickr.xml | grep -o 'tags=.*toward.*' - | grep -c 'tags=.*toward.*toward.*'`"

echo -n "XML 2 from / 1 toward: "
echo "`grep -o 'tags=.*from.*' flickr.xml | grep -o 'tags=.*toward.*' - | grep -c 'tags=.*from.*from.*'`"

echo -n "XML 2 from / 2 toward: "
echo "`grep -o 'tags=.*from.*from.*' flickr.xml | grep -c 'tags=.*toward.*toward.*'`"

echo -n "XML from without toward: "
echo "`grep -o 'tags=.*from.*' flickr.xml | grep -vc toward -`"

echo -n "XML toward without from: "
echo "`grep -o 'tags=.*toward.*' flickr.xml | grep -vc from -`"

echo -n "XML neither: "
echo "`grep 'photo id' flickr.xml | grep -v node - | grep -vc from -`"

rm flickr.xml
