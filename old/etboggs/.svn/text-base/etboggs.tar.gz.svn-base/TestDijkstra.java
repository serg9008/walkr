import java.util.Iterator;
import java.util.LinkedList;

public class TestDijkstra {

    public static void main(String[] args) {

        Graph campus = new Graph("nodelist.json");

        System.out.println();
        LinkedList<String> shortestPath = campus.shortestPath("lh", "ad");
        System.out.println(shortestPath);
        System.out.println();

        shortestPath = campus.shortestPath("ub", "ub");
        System.out.println(shortestPath);
        System.out.println();

        shortestPath = campus.shortestPath("ue", "mc");
        System.out.println(shortestPath);
        System.out.println();

        shortestPath = campus.shortestPath("sw", "eg");
        System.out.println(shortestPath);
        System.out.println();

        shortestPath = campus.shortestPath("eg", "sw");
        System.out.println(shortestPath);
        System.out.println();

        shortestPath = campus.shortestPath("lw", "am");
        System.out.println(shortestPath);
        System.out.println();

        shortestPath = campus.shortestPath("am", "bq");
        System.out.println(shortestPath);
        System.out.println();

    }

}

