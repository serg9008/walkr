/* Mark De Zwaan (mdezwaan)
 * Evan Boggs (etboggs)
 * A594/C343
 * Assignment 7
 */

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.Set;
import java.util.HashMap;

import java.io.IOException;

import javax.imageio.ImageIO;

import java.awt.Image;
import java.awt.EventQueue;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D.Double;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.border.EmptyBorder;

import java.net.URL;

public class GraphGUI extends JFrame {

    private static final double centerLat = 39.170989;
    private static final double centerLon = -86.516827;
    private static final int zoom = 15;
    private static final int numPathLabels = 7;

    private JPanel contentPane;
    private JLabel selPhoto;
    private JLabel pathTitle;
    private JList pathList;
    private Graph campusGraph;
    private GoogleMapPanel googleMap;
    private ArrayList<JLabel> pathLabels;
    private LinkedList<Photo> pathPics;
    private HashMap<String,java.awt.geom.Point2D.Double> graphNodes;
    private HashMap<String,java.awt.geom.Line2D.Double> graphEdges;

    private String startNode;
    private String endNode;

    private int photoPathIndex = -1;
    private int selPhotoIndex = -1;
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
                public void run() {
                    GraphGUI frame = new GraphGUI();
                    frame.setVisible(true);
                }
            });
    }

    public GraphGUI() {
        campusGraph = new Graph("nodelist.json");
        startNode = null;
        endNode = null;


        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(250, 250, 930, 660);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // GOOGLE MAP
        JLabel mapTitle = new JLabel("Map:");
        mapTitle.setBounds(20, 5, 100, 15);
        contentPane.add(mapTitle);

        Image googleImage = getGoogleMap(480);
        GoogleMap converter = new GoogleMap(centerLat, centerLon, zoom, 480,
                                            480);

        // Populate list of nodes
        LinkedList<java.awt.geom.Point2D.Double> nodeLocs =
            new LinkedList<java.awt.geom.Point2D.Double>();
        graphNodes = new HashMap<String,java.awt.geom.Point2D.Double>();
        Set<String> campusKeys = campusGraph.keySet();
        Iterator<String> it = campusKeys.iterator();
        while(it.hasNext()) {
            String elt = it.next();
            java.awt.geom.Point2D.Double locToAdd = new java.awt.geom.Point2D.Double();
            double x = converter.longitudeToX(campusGraph.getLongitude(elt));
            double y = converter.latitudeToY(campusGraph.getLatitude(elt));
            locToAdd.setLocation(x, y);
            nodeLocs.add(locToAdd);
            graphNodes.put(elt, locToAdd);
        }

        // Populate list of edges
        LinkedList<java.awt.geom.Line2D.Double> edgeLines =
            new LinkedList<java.awt.geom.Line2D.Double>();
        graphEdges = new HashMap<String,java.awt.geom.Line2D.Double>();
        it = campusKeys.iterator();
        while(it.hasNext()) {
            String sourceNode = it.next();
            LinkedList<String> edges = campusGraph.getEdges(sourceNode);

            for (int i = 0; i < edges.size(); i++) {
                java.awt.geom.Line2D.Double lineToAdd = new java.awt.geom.Line2D.Double(graphNodes.get(sourceNode), graphNodes.get(edges.get(i)));
                edgeLines.add(lineToAdd);
                String edgeKey = sourceNode + "_" + edges.get(i);
                graphEdges.put(edgeKey, lineToAdd);
            }
        }

        googleMap = new GoogleMapPanel(googleImage, nodeLocs, edgeLines);
        googleMap.setBounds(20, 20, 480, 480);
        googleMap.addMouseListener(new MouseListener() {
                public void mouseClicked(MouseEvent e) {
                    checkClickLocation(e.getX(), e.getY());
                }

                public void mousePressed(MouseEvent e) {}

                public void mouseReleased(MouseEvent e) {}

                public void mouseEntered(MouseEvent e) {}

                public void mouseExited(MouseEvent e) {}
            });
        contentPane.add(googleMap);


        // PHOTO PATH LIST
        pathTitle = new JLabel("Photos of selected path:");
        pathTitle.setBounds(20, 505, 500, 15);
        contentPane.add(pathTitle);

        JButton scrollLeft = new JButton("<");
        scrollLeft.setBounds(20, 525, 50, 100);
        scrollLeft.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if (photoPathIndex != 0) {
                        photoPathIndex -= 7;
                        updateLabels();
                    }
                }
            });
        contentPane.add(scrollLeft);

        // Photo path list labels get MouseListeners and then added to the
        // contentPane
        pathLabels = new ArrayList<JLabel>();
        int x = 80;
        for (int i = 0; i < numPathLabels; i++) {
            pathLabels.add(new JLabel());
            pathLabels.get(i).setBounds(x, 525, 100, 100);
            pathLabels.get(i).addMouseListener(new LabelMouseListener(i));
            contentPane.add(pathLabels.get(i));
            x += 110;
        }

        JButton scrollRight = new JButton(">");
        scrollRight.setBounds(850, 525, 50, 100);
        scrollRight.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    if ((photoPathIndex+7) < pathPics.size()) {
                        photoPathIndex += 7;
                        updateLabels();
                    }
                }
            });
        contentPane.add(scrollRight);

        // SELECTED PHOTO
        JLabel selTitle = new JLabel("Selected Photo:");
        selTitle.setBounds(540, 70, 200, 15);
        contentPane.add(selTitle);

        selPhoto = new JLabel("");
        selPhoto.setBounds(540, 90, 320, 320);
        contentPane.add(selPhoto);
    
        // to scroll to previous photo in pass list on selPhoto label
        JButton prevPhoto = new JButton("Previous");
        prevPhoto.setBounds(560, 430, 130, 50);
        prevPhoto.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // shouldn't scroll to prev if selPhotoIndex is 0 or less
                    if (selPhotoIndex > 0) {
                        scrollSelectedPhoto("prev");
                    }
                }
            });
        contentPane.add(prevPhoto);

        // to scroll to next photo in pass list on selPhoto label
        JButton nextPhoto = new JButton("Next");
        nextPhoto.setBounds(730, 430, 130, 50);
        nextPhoto.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    // shouldn't scroll to prev if selPhotoIndex is -1 
                    // (selPhoto label is empty) or if at the last element
                    // in pathPics list
                    if ((selPhotoIndex >= 0) && 
                        (selPhotoIndex < (pathPics.size()-1))) {
                        scrollSelectedPhoto("next");
                    }
                }
            });
        contentPane.add(nextPhoto);
    }

    /* Retrieves static map image from Google API
     */
    private Image getGoogleMap(Integer size) {
        Image result = null;
        try {
            /* Code to determine centerLat/centerLon/zoom based upon
             * north/south/east/westmost nodes per the assignment.
             * This functionality is not used in our current version because
             * we deemed it a sub-optimal representation of the campus.

             Set keys = campusGraph.keySet();
             Iterator<String> it = keys.iterator();
             String elt = it.next();
             double latitude = campusGraph.getLatitude(elt);
             double longitude = campusGraph.getLongitude(elt);
             northernmost = southernmost = latitude;
             easternmost = westernmost = longitude;
             while (it.hasNext()) {
             elt = it.next();
             latitude = campusGraph.getLatitude(elt);
             longitude = campusGraph.getLongitude(elt);
             if (latitude > northernmost)
             northernmost = latitude;
             if (latitude < southernmost)
             southernmost = latitude;
             if (longitude > easternmost)
             easternmost = longitude;
             if (longitude < westernmost)
             westernmost = longitude;
             }
             centerLat = ((northernmost + southernmost) / 2.0);
             centerLon = ((easternmost + westernmost) / 2.0);
            */

            // build Google Maps URL to include the four farthest nodes
            StringBuilder url = new StringBuilder();
            url.append("http://maps.google.com/maps/api/staticmap?");
            url.append("size=").append(size).append("x").append(size);
            url.append("&sensor=false");
            url.append("&center=");
            url.append(centerLat).append(",").append(centerLon);
            url.append("&zoom=").append(zoom);

            // get map and return as Image
            URL photoURL = new URL(url.toString());
            result = ImageIO.read(photoURL);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    /* Called by googleMap MouseListener when GoogleMapPanel is clicked.
     * Checks if any node in GoogleMapPanel was clicked on.
     */
    private void checkClickLocation(int x, int y) {
        if (graphNodes.size() == 0)
            return;

        Iterator<String> it = graphNodes.keySet().iterator();
        while (it.hasNext()) {
            String elt = it.next();
            int eltX = (int)graphNodes.get(elt).getX();
            int eltY = (int)graphNodes.get(elt).getY();
            // Click range for each node is 5 wide and 5 high
            if ((x > (eltX - 3)) && (x < (eltX + 3)) &&
                (y > (eltY - 3)) && (y < (eltY + 3))) {
                updateNodes(elt);

                if (startNode != null && endNode != null) {
                    LinkedList<String> shortestPath = campusGraph.shortestPath(startNode, endNode);

                    pathPics = campusGraph.getPathPhotos(shortestPath);
                    photoPathIndex = 0;
                    selPhoto.setIcon(null);
                    selPhotoIndex = -1;
                    updateLabels();
                    String titleText = ("Photos of selected path (" +
                                        Integer.toString(pathPics.size()) + "):");
                    pathTitle.setText(titleText);

                    // get nodes along shortest path
                    LinkedList<java.awt.geom.Point2D.Double> nodes =
                        new LinkedList<java.awt.geom.Point2D.Double>();
                    for (int i = 0; i < shortestPath.size(); i++) {
                        nodes.add(graphNodes.get(shortestPath.get(i)));
                    }

                    // get edges along shortest path
                    LinkedList<java.awt.geom.Line2D.Double> edgesInGraph =
                        new LinkedList<java.awt.geom.Line2D.Double>();
                    LinkedList<java.awt.geom.Line2D.Double> edgesNotInGraph =
                        new LinkedList<java.awt.geom.Line2D.Double>();
                    for (int i = 0; i < (shortestPath.size() - 1); i++) {
                        String edgeKey = (shortestPath.get(i) + "_" +
                                          shortestPath.get(i+1));
                        // store edges that are in path (for drawSelectedPath)
                        if (graphEdges.containsKey(edgeKey))
                            edgesInGraph.add(graphEdges.get(edgeKey));
                        // store edges that are not in path (for drawSelectedPath)
                        else {
                            String sourceNode = shortestPath.get(i);
                            String destNode = shortestPath.get(i+1);
                            edgesNotInGraph.add(new java.awt.geom.Line2D.Double(graphNodes.get(sourceNode), graphNodes.get(destNode)));
                        }
                    }

                    // pass in both edge lists so GUI knows to draw correct color
                    // line for specific edges (black if edges are in graph, blue
                    // if shortestPath has to jump to closest node in order to complete
                    // path
                    googleMap.drawSelectedPath(nodes, edgesInGraph, edgesNotInGraph);
                }
            }
        }

        return;
    }

    /* Called when scrollLeft or scrollRight JButton is pressed. Refreshes
     * JLabels at bottom that hold the photos from the path list.
     */
    private void updateLabels() {
        for (int i = 0; i < numPathLabels; i++) {
            if ((photoPathIndex + i) < pathPics.size()) {
                Photo photo = pathPics.get(photoPathIndex + i);
                if (photo != null) {
                    Image thumbnail = photo.getThumbnail();
                    pathLabels.get(i).setIcon(new ImageIcon(thumbnail));
                }
                else
                    pathLabels.get(i).setIcon(null);
            }
            else
                pathLabels.get(i).setIcon(null);
        }
    }

    /* Logic for selecting a path in the GUI (updating startNode and endNode)
     */
    private void updateNodes(String id) {
        if (startNode == null) {
            startNode = id;
            System.out.println("Start Node was updated to: " + startNode);
        }
        // if startNode = id and endNode is empty, then assume user has clicked
        // twice on startNode, do nothing
        else if (startNode.equals(id) && endNode == null)
            return;
        else if (startNode != null && endNode == null) {
            endNode = id;
            System.out.println("End Node was updated to: " + endNode);
        }
        else {
            startNode = id;
            endNode = null;
            System.out.println("Start Node was updated to: " + startNode);
            System.out.println("End Node was updated to: " + endNode);
        }
    }

    /* Updates the selPhoto JLabel to reflect the selected photo in the
     *  JLabel from the path list.  Displays a scaled instance.
     */
    private void changeSelectedPhoto(int pathLabelIndex) {
        int selPhotoInd = pathLabelIndex + photoPathIndex;
        if (selPhotoInd < pathPics.size()) {
            Photo photo = pathPics.get(selPhotoInd);
            // be sure to update global selPhotoIndex variable
            selPhotoIndex = selPhotoInd;
            Image image = photo.getImage();
            selPhoto.setIcon(new ImageIcon(image.getScaledInstance(320,320,Image.SCALE_DEFAULT)));
        }
    }

    /* Gets the next or previous photo in the pathPics array with respect to 
     * selPhoto's current icon photo.
     */
    private void scrollSelectedPhoto(String direction) {
        if (direction.equals("prev")) 
            selPhotoIndex--;

        else // direction.equals("next");
            selPhotoIndex++;

        Photo photo = pathPics.get(selPhotoIndex);
        Image image = photo.getImage();
        selPhoto.setIcon(new ImageIcon(image.getScaledInstance(320,320,Image.SCALE_DEFAULT)));            
    }

    /* Custom MouseListener that also stores the index of the parent pathLabel
     * in the array of pathLabels.
     */
    private class LabelMouseListener implements MouseListener {
        int index;

        public LabelMouseListener(int index) {
            this.index = index;
        }

        public void mouseClicked(MouseEvent e) {
            changeSelectedPhoto(index);
        }

        public void mousePressed(MouseEvent e) {}

        public void mouseReleased(MouseEvent e) {}

        public void mouseEntered(MouseEvent e) {}

        public void mouseExited(MouseEvent e) {}
    };
}

