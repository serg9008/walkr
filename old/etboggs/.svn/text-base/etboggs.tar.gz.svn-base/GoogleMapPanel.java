/* Mark De Zwaan (mdezwaan)
 * Evan Boggs (etboggs)
 * A594/C343
 * Assignment 7
 */

import java.util.LinkedList;
import java.util.Iterator;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.geom.Point2D.Double;
import java.awt.Graphics2D;
import java.awt.AlphaComposite;


import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.ImageIcon;

public class GoogleMapPanel extends JPanel {
    private Image graphMap;
    private LinkedList<java.awt.geom.Point2D.Double> locs;
    private LinkedList<java.awt.geom.Line2D.Double> lines;
    private LinkedList<java.awt.geom.Line2D.Double> jumps;
    private LinkedList<java.awt.geom.Point2D.Double> mostRecentNodes;

    public GoogleMapPanel(Image graphMap, LinkedList<java.awt.geom.Point2D.Double> locs, LinkedList<java.awt.geom.Line2D.Double> lines) {
        super();
        JLabel map = new JLabel("");
        this.add(map);
        map.setIcon(new ImageIcon(graphMap));
        this.locs = locs;        
        this.lines = lines;
        jumps = new LinkedList<java.awt.geom.Line2D.Double>();
        mostRecentNodes = new LinkedList<java.awt.geom.Point2D.Double>();
    }

    /* Overidden to display node ovals and edge lines upon paint call
     */
    public void paint(Graphics g) {
        super.paint(g);
        
        drawNodes(locs, g);

        // Show all edges on map
        if (mostRecentNodes.size() == 0) 
            g.setColor(java.awt.Color.BLUE);        
        else { // Just draw determined path
            drawNodes(mostRecentNodes, g);
            g.setColor(java.awt.Color.BLACK);
        }

        Iterator<java.awt.geom.Line2D.Double> itr = lines.iterator();
        while (itr.hasNext()) {
            Graphics2D g2 = (Graphics2D)g;
            java.awt.geom.Line2D.Double elt = itr.next();
            g2.draw(elt);
        }

        // Draw lines between nodes for which there are no edge photos
        g.setColor(java.awt.Color.BLUE);
        itr = jumps.iterator();
        while (itr.hasNext()) {
            Graphics2D g2 = (Graphics2D)g;
            java.awt.geom.Line2D.Double elt = itr.next();
            g2.draw(elt);
        }
    }

    /* Draws the path passed in (presumably from shortestPath) on map
     */
    public void drawSelectedPath(LinkedList<java.awt.geom.Point2D.Double> pathNodes, LinkedList<java.awt.geom.Line2D.Double> linesInGraph, LinkedList<java.awt.geom.Line2D.Double> linesNotInGraph) {
        lines.clear();
        mostRecentNodes = pathNodes;
        this.lines = linesInGraph;
        this.jumps = linesNotInGraph;
        repaint();
    }

    /* Draws the nodes passed in on map with the passed in graphics object
     */
    private void drawNodes(LinkedList<java.awt.geom.Point2D.Double> nodes, Graphics g) {
        if (nodes.equals(locs))
            g.setColor(java.awt.Color.RED);
        else // node.equals(mostRecentNodes)
            g.setColor(java.awt.Color.BLACK);
            
       
        Iterator<java.awt.geom.Point2D.Double> it = nodes.iterator();
        while (it.hasNext()) {
            java.awt.geom.Point2D.Double elt = it.next();
            g.drawOval(((int)elt.getX() - 2), ((int)elt.getY() - 2), 4, 4);
            g.fillOval(((int)elt.getX() - 2), ((int)elt.getY() - 2), 4, 4);
        }
    }

}
