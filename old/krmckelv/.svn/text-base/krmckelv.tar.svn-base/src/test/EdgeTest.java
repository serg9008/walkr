package test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import flickr.Flickr;
import flickr.Photo;
import graph.Edge;

public class EdgeTest {

	@Test
	public void testGetPhotos() {
		fail("Not yet implemented");
	}

	@Test
	public void testSortPhotos() {
		fail("Not yet implemented");
	}

}
